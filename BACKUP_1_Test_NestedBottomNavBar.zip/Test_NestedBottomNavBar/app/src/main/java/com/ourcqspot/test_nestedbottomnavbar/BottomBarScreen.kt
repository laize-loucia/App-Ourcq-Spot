package com.ourcqspot.test_nestedbottomnavbar

import android.util.Log
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BottomBarScreen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    companion object {
        val SCREENS = listOf(
            Home,
            Profile,
            Settings,
            Other,
        )
        var lastScreen = SCREENS.first()

        fun checkIfDestinationRouteIsBefore(destinationRoute: String): Boolean {
            Log.d(
                "ARFAFAVUFAUYVFA",
                lastScreen.route
            )
            Log.d(
                "ARFAFAVUFAUYVFA--2",
                destinationRoute
            )
            for (screen in SCREENS) {
                when (screen.route) {
                    lastScreen.route -> {
                        return false
                    }
                    destinationRoute -> {
                        return true
                    }
                    else -> {}
                }
            }
            return false;
        }
    }

    object Home : BottomBarScreen(
        route = "HOME",
        title = "HOME",
        icon = Icons.Default.Home
    )

    object Profile : BottomBarScreen(
        route = "PROFILE",
        title = "PROFILE",
        icon = Icons.Default.Person
    )

    object Settings : BottomBarScreen(
        route = "SETTINGS",
        title = "SETTINGS",
        icon = Icons.Default.Settings
    )

    // TEST --- should be enabled in companion and in HomeScreen as well
    object Other : BottomBarScreen(
        route = "OTHER",
        title = "OTHER",
        icon = Icons.Default.Search
    )
    object Account : BottomBarScreen(
        route = "ACCOUNT",
        title = "ACCOUNT",
        icon = Icons.Default.AccountCircle
    )
}
