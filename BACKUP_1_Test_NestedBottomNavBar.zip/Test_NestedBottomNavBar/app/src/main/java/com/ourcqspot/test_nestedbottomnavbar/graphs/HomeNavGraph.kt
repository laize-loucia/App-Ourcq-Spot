package com.ourcqspot.test_nestedbottomnavbar.graphs

import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navigation
import com.ourcqspot.test_nestedbottomnavbar.BottomBarScreen
import com.ourcqspot.test_nestedbottomnavbar.BottomBarScreen.Companion.checkIfDestinationRouteIsBefore
import com.ourcqspot.test_nestedbottomnavbar.screens.ScreenContent

@Composable
fun HomeNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        route = Graph.HOME,
        startDestination = BottomBarScreen.Home.route,
        enterTransition = {
            var towardsDirection = AnimatedContentTransitionScope.SlideDirection.Right
            if ( initialState.destination.route?.let {
                    checkIfDestinationRouteIsBefore(it)
                } == true) {
                towardsDirection = AnimatedContentTransitionScope.SlideDirection.Left
            }
            slideIntoContainer(
                towards = towardsDirection,
                animationSpec = tween(700)
            )
        },
        exitTransition = {
            var towardsDirection = AnimatedContentTransitionScope.SlideDirection.Right
            if ( initialState.destination.route?.let {
                    checkIfDestinationRouteIsBefore(it)
                } == true) {
                towardsDirection = AnimatedContentTransitionScope.SlideDirection.Left
            }
            slideOutOfContainer(
                towards = towardsDirection,
                animationSpec = tween(700)
            )
        },
        /*popEnterTransition = {
            slideIntoContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(700)
            )
        },
        popExitTransition = {
            slideOutOfContainer(
                towards = AnimatedContentTransitionScope.SlideDirection.Right,
                animationSpec = tween(700)
            )
            /*when (initialState.destination.route) {
                BottomBarScreen.SCREENS.first().route,
                BottomBarScreen.SCREENS.last().route
                    -> towardsDirection = AnimatedContentTransitionScope.SlideDirection.Right
                //else -> {} // ExitTransition.None
            }*/
        }*/
    ) {
        composable(route = BottomBarScreen.Home.route) {
            ScreenContent (
                name = BottomBarScreen.Home.route,
                useHypertextStyle = true,
                onClick = {
                    navController.navigate(Graph.DETAILS)
                }
            )
        }
        composable(route = BottomBarScreen.Profile.route) {
            ScreenContent(
                name = BottomBarScreen.Profile.route,
                onClick = { }
            )
        }
        composable(route = BottomBarScreen.Settings.route) {
            ScreenContent(
                name = BottomBarScreen.Settings.route,
                onClick = { }
            )
        }
        if (BottomBarScreen.Other in BottomBarScreen.SCREENS) {
            composable(route = BottomBarScreen.Other.route) {
                ScreenContent(
                    name = BottomBarScreen.Other.route,
                    onClick = { }
                )
            }
        }
        detailsNavGraph(navController = navController)
    }
}

fun NavGraphBuilder.detailsNavGraph(navController: NavHostController) {
    navigation(
        route = Graph.DETAILS,
        startDestination = DetailsScreen.Information.route
    ) {
        composable(route = DetailsScreen.Information.route) {
            ScreenContent(name = DetailsScreen.Information.route) {
                navController.navigate(DetailsScreen.Overview.route)
            }
        }
        composable(route = DetailsScreen.Overview.route) {
            ScreenContent(name = DetailsScreen.Overview.route) {
                navController.popBackStack(
                    route = DetailsScreen.Information.route,
                    inclusive = false
                )
            }
        }
    }
}

sealed class DetailsScreen(val route: String) {
    object Information : DetailsScreen(route = "INFORMATION")
    object Overview : DetailsScreen(route = "OVERVIEW")
}
