//package com.example.nestednavigationbottombardemo
package com.ourcqspot.test_nestedbottomnavbar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController
import com.example.nestednavigationbottombardemo.ui.theme.NestedNavigationBottomBarDemoTheme
import com.ourcqspot.test_nestedbottomnavbar.graphs.HomeNavGraph
import com.ourcqspot.test_nestedbottomnavbar.graphs.RootNavGraph

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NestedNavigationBottomBarDemoTheme {
                RootNavGraph(navController = rememberNavController())
                //HomeNavGraph(navController = rememberNavController())
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun RootElementPreview() {
        RootNavGraph()
    }
    @Preview(showBackground = true)
    @Composable
    fun HomeElementPreview() {
        HomeNavGraph()
    }
}